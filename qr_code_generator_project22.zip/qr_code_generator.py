import qrcode

def generate_qr():
    data = input('Enter text or URL: ')
    img = qrcode.make(data)
    img.save('qrcode.png')
    print('QR code saved as qrcode.png')

if __name__ == '__main__':
    generate_qr()
