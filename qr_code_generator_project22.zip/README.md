# QR Code Generator Project

## Description
This is a basic QR Code Generator built using Python. It allows users to input text or a URL and generates a QR code image.

## Features
- Simple command-line interface
- Accepts text or URL input
- Generates a QR code image
- Saves the image locally

## Requirements
- Python 3
- qrcode
- PIL (Pillow)

## Usage
Run the script using Python:

```bash
python qr_code_generator.py
```

Then enter the desired text or URL when prompted.
